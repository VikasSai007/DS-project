package service;

import java.util.List;

import entities.Vehicle;

public interface VehcileDetailsService {
	void createVehicleDetailsService(Vehicle vehicle);
	Vehicle findVehicleDetailsService(int userId);
	List<Vehicle> findVehicleDetailsService();
	void modifyVehicleDetailsService(Vehicle vehicle);
	void removeVehicleDetailsService(int userId);

}
