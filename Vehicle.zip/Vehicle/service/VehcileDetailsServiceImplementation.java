package service;

import java.util.List;

import dao.VehicleDetailsDAO;
import dao.VehicleDetailsDAOImplementation;
import entities.Vehicle;

public class VehcileDetailsServiceImplementation implements VehcileDetailsService {
	VehicleDetailsDAO vehicleDAO = new VehicleDetailsDAOImplementation();
	public void createVehicleDetailsService(Vehicle vehicle) {
		vehicleDAO.insertVehicleDetails(vehicle);
	}
	public Vehicle findVehicleDetailsService(int userId) {	
		return vehicleDAO.selectVehicleDetails(userId);
	}
	public List<Vehicle> findVehicleDetailsService() {
		return vehicleDAO.selectVehicleDetails();
	}
	public void modifyVehicleDetailsService(Vehicle vehicle) {
		vehicleDAO.updateVehicleDetails(vehicle);
	}
	public void removeVehicleDetailsService(int userId) {
		vehicleDAO.deleteVehicleDetails(userId);
	}
}
