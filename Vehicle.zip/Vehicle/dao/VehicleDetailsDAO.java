package dao;

import java.util.List;

import entities.Vehicle;

public interface VehicleDetailsDAO{
	public void insertVehicleDetails(Vehicle vehicle); //C
	public Vehicle selectVehicleDetails(int userId);//R
	public List<Vehicle> selectVehicleDetails(); //RA
	public void updateVehicleDetails(Vehicle vehicle); //U
	public void deleteVehicleDetails(int userId); 
}
