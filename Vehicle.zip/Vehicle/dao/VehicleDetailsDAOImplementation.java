package dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entities.Vehicle; 

public class VehicleDetailsDAOImplementation implements VehicleDetailsDAO{
Connection conn ; 
	
	public VehicleDetailsDAOImplementation() 
	{
		try {
		
			System.out.println("Trying to load the driver...");
		    DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded....");
			
			
			System.out.println("Trying to connect....");
			conn = 	DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected : "+ conn);
			
						
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	
	public void insertVehicleDetails(Vehicle vehicle) {
		
		
		try {
			PreparedStatement pst = conn.prepareStatement("INSERT INTO INSDB VALUES (?,?,?,?,?,?,?,?,?,?)");

			pst.setInt(1, vehicle.getUserId());
            pst.setInt(2, vehicle.getVehicleId());
			pst.setString(3, vehicle.getVehicleType());
			pst.setString(4,vehicle.getVehicleManufacturer());
            pst.setString(5, vehicle.getVehicleModel());
			pst.setString(6, vehicle.getDrivingLicense());
			pst.setString(7,vehicle.getPurchaseDate());
			pst.setInt(8, vehicle.getRegistrationNumber());
			pst.setString(9,vehicle.getEngineNumber());
			pst.setString(10,vehicle.getChasisNumber());
			
			
			
			System.out.println("PreparedStatement is created : "+ pst);
			
			
			int rows = pst.executeUpdate();
			
			System.out.println("Rows created : "+rows);
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
	
	}
	
    public Vehicle selectVehicleDetails(int userId) {
		
    	Vehicle vehicleObject =null;
		try {
			
			statement = conn.createStatement();
			System.out.println("Statement is created : "+ statement);
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM INSDB WHERE USERID="+userId);
			
			
			if(result.next()) {
				vehicleObject = new Vehicle(); 
				
				vehicleObject.setUserId(result.getInt(1));
				vehicleObject.setVehicleId(result.getInt(2));
				vehicleObject.setVehicleType(result.getString(3));
				vehicleObject.setVehicleManufacturer(result.getString(4));
				vehicleObject.setVehicleModel(result.getString(5));
				vehicleObject.setDrivingLicense(result.getString(6));
				vehicleObject.setPurchaseDate(result.getString(7));
				vehicleObject.setRegistrationNumber(result.getInt(8));
				vehicleObject.setEngineNumber(result.getString(9));
				vehicleObject.setChasisNumber(result.getString(10));
				
				

			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return vehicleObject;
	}
    
   public List<Vehicle> selectVehicleDetails() {
		
		List<Vehicle> insList = new ArrayList<Vehicle>();
		try {
			
			 
			Statement statement = conn.createStatement();
			System.out.println("Statement is created : "+ statement);
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM INSDB");
			
			
			while(result.next()) 
			{
				Vehicle vehicleObject = new Vehicle(); 
				
			
				vehicleObject.setUserId(result.getInt(1));
				vehicleObject.setVehicleId(result.getInt(2));
				vehicleObject.setVehicleType(result.getString(3));
				vehicleObject.setVehicleManufacturer(result.getString(4));
				vehicleObject.setVehicleModel(result.getString(5));
				vehicleObject.setDrivingLicense(result.getString(6));
				vehicleObject.setPurchaseDate(result.getString(7));
				vehicleObject.setRegistrationNumber(result.getInt(8));
				vehicleObject.setEngineNumber(result.getString(9));
				vehicleObject.setChasisNumber(result.getString(10));
			}
		    }
		   catch (SQLException e) {
			
			e.printStackTrace();
		   }
		   return insList;
	}
   
   public void updateVehicleDetails(Vehicle vehicle) 
   {
		
		
		try {
			PreparedStatement pst =conn.prepareStatement("UPDATE INSDB vid=?, vtype=? ,vmanu=? ,vmod=?,dl=?,date=?,rno=?,eno=?,chno=? =>where uid=?");
					
			
            pst.setInt(10, vehicle.getUserId());
            pst.setInt(1, vehicle.getVehicleId());
			pst.setString(2,vehicle.getVehicleType());
			pst.setString(3,vehicle.getVehicleManufacturer());
            pst.setString(4, vehicle.getVehicleModel());
			pst.setString(5, vehicle.getDrivingLicense());
			pst.setString(6,vehicle.getPurchaseDate());
			pst.setInt(7, vehicle.getRegistrationNumber());
			pst.setString(8,vehicle.getEngineNumber());
			pst.setString(9, vehicle.getChasisNumber());
			System.out.println("PreparedStatement is created : "+ pst);
					
					
			int rows = pst.executeUpdate();
					
			System.out.println("Row MODIFIED : "+rows);
		} 
		catch (SQLException e) 
		{
					
			e.printStackTrace();
		}
	}
   public void deleteVehicleDetails(int userId) {
		
		
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM INSDB where uid=?");
			
			pst.setInt(1,userId); 

			
			System.out.println("PreparedStatement is created : "+ pst);
			
			
			int rows = pst.executeUpdate();
			
			System.out.println("Row DELETED : "+rows);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}
