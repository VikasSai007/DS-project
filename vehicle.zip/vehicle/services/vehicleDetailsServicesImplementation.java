package services;


import java.util.List;

import dao.vehicleDetailsDAO;
import dao.vehicleDetailsDAOImplementation;
import entities.vehicle;

public class vehicleDetailsServicesImplementation implements vehicleDetailsServices{
	vehicleDetailsDAO insDAO = new vehicleDetailsDAOImplementation();
	public void createVehicleDetailsService(vehicle ins) {
			insDAO.insertVehicleDetails(ins);
	}
	public vehicle findVehicleDetailsService(int userId) {	
		return insDAO.selectVehicleDetails(userId);
	}
	public List<vehicle> findVehicleDetailsService() {
		return insDAO.selectVehicleDetails();
	}
	public void modifyVehicleDetailsService(vehicle ins) {
		insDAO.updateVehicleDetails(ins);
	}
	public void removeVehicleDetailsService(int userId) {
		insDAO.deleteVehicleDetails(userId);
	}

}
