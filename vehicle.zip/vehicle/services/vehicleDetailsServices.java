package services;

import java.util.List;

import entities.vehicle;

public interface vehicleDetailsServices {
	void createVehicleDetailsService(vehicle ins);
	vehicle findVehicleDetailsService(int userId);
	List<vehicle> findVehicleDetailsService();
	void modifyVehicleDetailsService(vehicle ins);
	void removeVehicleDetailsService(int userId);
}
