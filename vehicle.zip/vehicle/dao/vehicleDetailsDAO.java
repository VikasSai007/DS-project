package dao;

import java.util.List;

import entities.vehicle;

public interface vehicleDetailsDAO {
	public void insertVehicleDetails(vehicle ins); //C
	public vehicle selectVehicleDetails(int userId);//R
	public List<vehicle> selectVehicleDetails(); //RA
	public void updateVehicleDetails(vehicle ins); //U
	public void deleteVehicleDetails(int userId); 
}

