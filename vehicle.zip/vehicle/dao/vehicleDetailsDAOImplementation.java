package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import entities.vehicle;

public class vehicleDetailsDAOImplementation implements vehicleDetailsDAO 
{
    Connection conn ; 
	
	public vehicleDetailsDAOImplementation() 
	{
		try {
		
			System.out.println("Trying to load the driver...");
		    DriverManager.registerDriver(new org.hsqldb.jdbc.JDBCDriver());
			System.out.println("Driver loaded....");
			
			
			System.out.println("Trying to connect....");
			conn = 	DriverManager.getConnection("jdbc:hsqldb:hsql://localhost/xdb", "SA", "");
			System.out.println("Connected : "+ conn);
			
						
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}
	
	
	public void insertVehicleDetails(vehicle ins) {
		
		
		try {
			PreparedStatement pst = 
					conn.prepareStatement("INSERT INTO INSDB VALUES (?,?,?,?,?,?,?,?,?,?)");

			pst.setInt(1, ins.getUserId());
            pst.setInt(2, ins.getVehicleId());
			pst.setstring(3, ins.getVehicleType());
			pst.setString(4,ins.getVehicleManufacturer());
            pst.setString(5, ins.getVehicleModel());
			pst.setString(6, ins.getDrivingLicense());
			pst.setString(7,ins.getPurchaseDate());
			pst.setInt(8, ins.getRegistrationNumber());
			pst.setString(9,ins.getEngineNumber());
			pst.setString(10, ins.getChasisNumber());
			
			
			
			System.out.println("PreparedStatement is created : "+ pst);
			
			
			int rows = pst.executeUpdate();
			
			System.out.println("Rows created : "+rows);
		} 
		catch (SQLException e) 
		{
			
			e.printStackTrace();
		}
	
	}
	
    public vehicle selectVehicleDetails(int userId) {
		
    	vehicle insObj =null;
		try {
			
			Statement statement = conn.createStatement();
			System.out.println("Statement is created : "+ statement);
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM INSDB WHERE REGNO="+regNumber);
			
			
			if(result.next()) {
				insObj = new vehicle(); 
				
				insObj.setUserId(result.getInt(1));
                insObj.setVehicelId(result.getInt(2));
				insObj.setvehcileType(result.getstring(3));
				insObj.setVehcileManufacturer(result.getString(4));
                insObj.setVehcileModel(result.getString(5));
				insObj.setDrivingLicense(result.getString(6));
				insObj.setPurchaseDate(result.getString(7));
				insObj.setRegistrationNumber(result.getInt(8));
				insObj.setEngineNumber(result.getString(9));
				insObj.setChasisNumber(result.getString(10));
				
				

			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return insObj;
	}
    
   public List<vehicle> selectVehicleDetails() {
		
		List<vehicle> insList = new ArrayList<vehicle>();
		try {
			
			 
			Statement statement = conn.createStatement();
			System.out.println("Statement is created : "+ statement);
			
			
			ResultSet result = statement.executeQuery("SELECT * FROM INSDB");
			
			
			while(result.next()) 
			{
				vehicle insObj = new vehicle(); 
				
			
				insObj.setUserId(result.getInt(1));
                insObj.setVehicelId(result.getInt(2));
				insObj.setvehcileType(result.getstring(3));
				insObj.setVehcileManufacturer(result.getString(4));
                insObj.setVehcileModel(result.getString(5));
				insObj.setDrivingLicense(result.getString(6));
				insObj.setPurchaseDate(result.getString(7));
				insObj.setRegistrationNumber(result.getInt(8));
				insObj.setEngineNumber(result.getString(9));
				insObj.setChasisNumber(result.getString(10));
			}
		    }
		   catch (SQLException e) {
			
			e.printStackTrace();
		   }
		   return insList;
	}
   
   public void updateVehicleDetails(vehicle ins) 
   {
		
		
		try {
			PreparedStatement pst =conn.prepareStatement("UPDATE INSDB vid=?, vtype=? ,vmanu=? ,vmod=?,dl=?,date=?,rno=?,eno=?,chno=? =>where uid=?");
					
			
            pst.setInt(10, ins.getUserId());
            pst.setInt(1, ins.getVehicleId());
			pst.setstring(2, ins.getVehicleType());
			pst.setString(3,ins.getVehicleManufacturer());
            pst.setString(4, ins.getVehicleModel());
			pst.setString(5, ins.getDrivingLicense());
			pst.setString(6,ins.getPurchaseDate());
			pst.setInt(7, ins.getRegistrationNumber());
			pst.setString(8,ins.getEngineNumber());
			pst.setString(9, ins.getChasisNumber());
			System.out.println("PreparedStatement is created : "+ pst);
					
					
			int rows = pst.executeUpdate();
					
			System.out.println("Row MODIFIED : "+rows);
		} 
		catch (SQLException e) 
		{
					
			e.printStackTrace();
		}
	}
   public void deleteVehicleDetails(int userId) {
		
		
		try {
			PreparedStatement pst = conn.prepareStatement("DELETE FROM INSDB where uid=?");
			
			pst.setInt(1,userId); 

			
			System.out.println("PreparedStatement is created : "+ pst);
			
			
			int rows = pst.executeUpdate();
			
			System.out.println("Row DELETED : "+rows);
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	}

}



